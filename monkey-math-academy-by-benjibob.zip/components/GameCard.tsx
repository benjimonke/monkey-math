
import React from 'react';
import { Play, Flame } from 'lucide-react';
import { Game } from '../types';

interface GameCardProps {
  game: Game;
  onPlay: (game: Game) => void;
}

const GameCard: React.FC<GameCardProps> = ({ game, onPlay }) => {
  return (
    <div 
      className="group relative bg-[#1a1a1a] rounded-2xl overflow-hidden border border-gray-800 hover:border-yellow-400/50 transition-all duration-300 hover:-translate-y-1 cursor-pointer"
      onClick={() => onPlay(game)}
    >
      {/* Thumbnail */}
      <div className="aspect-[4/3] relative overflow-hidden">
        <img 
          src={game.thumbnail} 
          alt={game.title} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="bg-yellow-400 p-3 rounded-full shadow-xl shadow-yellow-400/20">
            <Play fill="black" className="text-black ml-1" />
          </div>
        </div>
        {game.isHot && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-md flex items-center gap-1 uppercase tracking-wider">
            <Flame size={12} /> Hot
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <h3 className="font-bold text-lg truncate group-hover:text-yellow-400 transition-colors">{game.title}</h3>
        <p className="text-xs text-gray-500 font-medium uppercase tracking-widest mt-1">{game.category}</p>
      </div>
    </div>
  );
};

export default GameCard;
