
import React, { useState } from 'react';
import { Search, Banana, Menu, X, Gamepad2, GraduationCap } from 'lucide-react';

interface NavbarProps {
  onSearch: (query: string) => void;
  onToggleFacade: () => void;
  isFacade: boolean;
}

const Navbar: React.FC<NavbarProps> = ({ onSearch, onToggleFacade, isFacade }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-[#0a0a0a]/90 backdrop-blur-md border-b border-yellow-500/20 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
          <div className="bg-yellow-400 p-2 rounded-xl">
            <Banana className="text-black w-6 h-6" />
          </div>
          <span className="text-xl font-monkey font-bold tracking-tight hidden sm:block">
            {isFacade ? 'MONKEY MATH' : 'PRIMATE PLAY'}
          </span>
        </div>

        {/* Search */}
        <div className="flex-1 max-w-xl relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search for unblocked games..." 
            className="w-full bg-[#1a1a1a] border border-gray-800 rounded-full py-2 pl-10 pr-4 focus:outline-none focus:border-yellow-400 transition-colors"
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-6">
          <button 
            onClick={onToggleFacade}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors text-sm font-medium"
          >
            {isFacade ? <Gamepad2 size={18} /> : <GraduationCap size={18} />}
            {isFacade ? 'Show Games' : 'Math Mode'}
          </button>
          <div className="w-10 h-10 rounded-full bg-yellow-400 overflow-hidden border-2 border-yellow-200">
            <img src="https://images.unsplash.com/photo-1540573133985-87b6da6d54a9?auto=format&fit=crop&q=80&w=100&h=100" alt="Avatar" />
          </div>
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-[#0a0a0a] border-b border-yellow-500/20 p-4 flex flex-col gap-4 animate-in fade-in slide-in-from-top-4">
          <button 
            onClick={() => { onToggleFacade(); setIsOpen(false); }}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-gray-800"
          >
            {isFacade ? <Gamepad2 size={18} /> : <GraduationCap size={18} />}
            {isFacade ? 'Show Games' : 'Math Mode'}
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
