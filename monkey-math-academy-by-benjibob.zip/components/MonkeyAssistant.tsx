
import React, { useState, useRef, useEffect } from 'react';
import { Send, X, MessageSquare, Bot } from 'lucide-react';
import { getMonkeyResponse } from '../services/geminiService';
import { ChatMessage } from '../types';

const MonkeyAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Ooh ooh! I am Professor Kong. Need help finding a game or a banana at benjibob\'s HQ? 🍌' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const response = await getMonkeyResponse(userMsg, history);
    setMessages(prev => [...prev, { role: 'model', text: response || 'No banana for that thought...' }]);
    setIsTyping(false);
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 bg-yellow-400 text-black p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all"
      >
        <MessageSquare />
      </button>

      <div className={`fixed inset-y-0 right-0 w-full sm:w-96 bg-[#0d0d0d] border-l border-gray-800 z-50 transition-transform duration-300 shadow-2xl flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="p-4 border-b border-gray-800 flex items-center justify-between bg-[#111]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center">
              <Bot className="text-black" />
            </div>
            <div>
              <h3 className="font-bold text-yellow-400">Professor Kong</h3>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest">Banana Powered AI</p>
            </div>
          </div>
          <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-gray-800 rounded-lg">
            <X />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={scrollRef}>
          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] px-4 py-2 rounded-2xl text-sm ${
                msg.role === 'user' 
                ? 'bg-yellow-400 text-black rounded-tr-none' 
                : 'bg-gray-800 text-white rounded-tl-none'
              }`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-gray-800 px-4 py-2 rounded-2xl rounded-tl-none flex gap-1 items-center">
                <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" />
                <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-[#111] border-t border-gray-800">
          <div className="relative">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask the monkey..." 
              className="w-full bg-[#1a1a1a] border border-gray-700 rounded-xl py-3 pl-4 pr-12 focus:outline-none focus:border-yellow-400 text-sm"
            />
            <button 
              onClick={handleSend}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-yellow-400 text-black p-2 rounded-lg hover:bg-yellow-300 transition-colors"
            >
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default MonkeyAssistant;
