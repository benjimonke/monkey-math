
import React, { useState, useMemo } from 'react';
import Navbar from './components/Navbar';
import GameCard from './components/GameCard';
import MonkeyAssistant from './components/MonkeyAssistant';
import { Game, GameCategory } from './types';
import { GAMES } from './constants';
import { X, Maximize2, Banana, Calculator, BookOpen, Bell, User, Lock, ExternalLink, ShieldCheck, Flame } from 'lucide-react';

const App: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<GameCategory>(GameCategory.ALL);
  const [isFacade, setIsFacade] = useState(false);
  const [playingGame, setPlayingGame] = useState<Game | null>(null);

  const filteredGames = useMemo(() => {
    return GAMES.filter(game => {
      const matchesSearch = game.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === GameCategory.ALL || game.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const toggleFacade = () => setIsFacade(!isFacade);

  if (playingGame) {
    return (
      <div className="fixed inset-0 z-[100] bg-black flex flex-col">
        <div className="bg-[#0d0d0d] px-4 py-2 flex items-center justify-between border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="bg-yellow-400 p-1.5 rounded-lg">
              <Banana className="text-black w-4 h-4" />
            </div>
            <h2 className="font-bold text-sm sm:text-base">{playingGame.title}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-800 rounded-lg text-gray-400" title="Full Screen">
              <Maximize2 size={18} />
            </button>
            <button 
              onClick={() => setPlayingGame(null)}
              className="p-2 hover:bg-red-500/20 hover:text-red-500 rounded-lg text-gray-400 transition-colors"
            >
              <X size={20} />
            </button>
          </div>
        </div>
        <iframe 
          src={playingGame.embedUrl} 
          className="flex-1 w-full h-full border-none"
          allowFullScreen
          title={playingGame.title}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 overflow-x-hidden">
      <Navbar onSearch={setSearchQuery} onToggleFacade={toggleFacade} isFacade={isFacade} />

      <main className="max-w-7xl mx-auto px-4 pt-8">
        {isFacade ? (
          /* "Math" Facade UI - Designed to look like Canvas/LMS */
          <div className="space-y-8 py-6 animate-in fade-in duration-500">
            <header className="flex flex-col sm:flex-row items-center justify-between bg-[#111] p-6 rounded-2xl border border-gray-800 gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-blue-600 rounded-xl flex items-center justify-center">
                  <BookOpen className="text-white w-8 h-8" />
                </div>
                <div>
                  <h1 className="text-xl sm:text-2xl font-bold">benjibob's Student Dashboard</h1>
                  <p className="text-gray-400 text-sm italic">"Learning is the ultimate banana." - Admin</p>
                </div>
              </div>
              <div className="flex gap-3">
                <button className="p-2 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors relative">
                    <Bell size={20} />
                    <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
                </button>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 rounded-lg text-sm font-bold">
                    <User size={16} /> Portal Login
                </button>
              </div>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column: Courses */}
                <div className="lg:col-span-2 space-y-6">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                        <Calculator size={18} className="text-blue-400" /> Active Courses
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {[
                            { name: "Primate Geometry", code: "MATH-102", color: "border-l-blue-500" },
                            { name: "Banana Economics", code: "ECON-201", color: "border-l-yellow-500" },
                            { name: "Tree-Climbing Physics", code: "PHYS-305", color: "border-l-green-500" },
                            { name: "Simian Social Studies", code: "HIST-110", color: "border-l-purple-500" }
                        ].map((course, i) => (
                            <div key={i} className={`bg-[#111] p-5 rounded-xl border border-gray-800 border-l-4 ${course.color} hover:bg-[#161616] transition-colors cursor-pointer group`}>
                                <h3 className="font-bold group-hover:text-blue-400 transition-colors">{course.name}</h3>
                                <p className="text-xs text-gray-500 mt-1 uppercase tracking-widest">{course.code}</p>
                                <div className="mt-4 h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-blue-500 w-[65%]" />
                                </div>
                                <p className="text-[10px] text-gray-500 mt-2">65% Course Completion</p>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Right Column: Sidebar */}
                <div className="space-y-6">
                    <h2 className="text-lg font-bold flex items-center gap-2">
                        <Lock size={18} className="text-orange-400" /> Announcements
                    </h2>
                    <div className="bg-[#111] rounded-2xl border border-gray-800 divide-y divide-gray-800 overflow-hidden">
                        {[
                            "New assignment: The peel coefficient.",
                            "Faculty meeting at the Great Oak.",
                            "Reminder: Final exams on Friday.",
                            "New syllabus: Jungle Navigation."
                        ].map((text, i) => (
                            <div key={i} className="p-4 text-sm text-gray-400 hover:bg-gray-800/50 transition-colors cursor-default">
                                {text}
                            </div>
                        ))}
                    </div>
                    <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 p-6 rounded-2xl border border-blue-500/20">
                        <h4 className="font-bold mb-2 text-blue-400 flex items-center gap-2"><ShieldCheck size={16} /> Secure Portal</h4>
                        <p className="text-xs text-gray-400 leading-relaxed">Study tools are verified for <strong>benjibob.github.io</strong> students.</p>
                    </div>
                </div>
            </div>
          </div>
        ) : (
          /* Actual Game UI */
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Hero */}
            <div className="relative rounded-[2rem] overflow-hidden mb-12 bg-gradient-to-br from-yellow-500/20 to-orange-600/10 border border-yellow-500/10">
              <div className="p-8 md:p-12 max-w-2xl relative z-10">
                <div className="inline-flex items-center gap-2 bg-yellow-400/10 border border-yellow-400/20 text-yellow-400 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-4">
                  <Flame size={14} /> Official benjibob Release
                </div>
                <h1 className="text-4xl md:text-6xl font-monkey font-extrabold mb-4 leading-tight">
                  Escape the Jungle,<br />
                  <span className="text-yellow-400 underline decoration-yellow-400/30">Master the Games.</span>
                </h1>
                <p className="text-gray-400 text-lg mb-8">
                  Welcome to the troop! Play the hottest unblocked games at school via <strong>benjibob.github.io/monkey-math</strong>.
                </p>
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => setPlayingGame(GAMES[0])}
                    className="bg-yellow-400 hover:bg-yellow-300 text-black px-8 py-4 rounded-2xl font-bold flex items-center gap-2 text-lg shadow-xl shadow-yellow-400/20 transition-all hover:-translate-y-0.5 active:translate-y-0"
                  >
                    Play Retro Bowl
                  </button>
                  <a 
                    href="https://github.com/benjibob" 
                    target="_blank"
                    className="bg-gray-800 hover:bg-gray-700 text-white px-8 py-4 rounded-2xl font-bold flex items-center gap-2 text-lg transition-all"
                  >
                    <ExternalLink size={20} /> Developer
                  </a>
                </div>
              </div>
              <div className="absolute right-0 bottom-0 top-0 w-1/2 opacity-20 pointer-events-none hidden md:block">
                 <img src="https://images.unsplash.com/photo-1540573133985-87b6da6d54a9?auto=format&fit=crop&q=80&w=800&h=800" className="w-full h-full object-cover grayscale" />
              </div>
            </div>

            {/* Filter Bar */}
            <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
              {Object.values(GameCategory).map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-5 py-2 rounded-full whitespace-nowrap transition-all text-sm font-semibold ${
                    selectedCategory === cat 
                    ? 'bg-yellow-400 text-black' 
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Game Grid */}
            {filteredGames.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                {filteredGames.map(game => (
                  <GameCard key={game.id} game={game} onPlay={setPlayingGame} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 space-y-4">
                <div className="bg-gray-800 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Banana size={40} className="text-gray-600 rotate-12" />
                </div>
                <h2 className="text-2xl font-bold">No Bananas Found!</h2>
                <p className="text-gray-500">We couldn't find any games matching your search.</p>
                <button 
                  onClick={() => { setSearchQuery(''); setSelectedCategory(GameCategory.ALL); }}
                  className="text-yellow-400 hover:underline font-bold"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-20 border-t border-gray-800 py-10 text-center">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2">
            <Banana className="text-yellow-400 w-5 h-5" />
            <span className="font-monkey font-bold">benjibob.github.io/monkey-math</span>
          </div>
          <div className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Monkey Math Unblocked. Official benjibob Edition.
          </div>
          <div className="flex gap-6 text-sm font-medium text-gray-400">
            <a href="https://github.com/benjibob" target="_blank" className="hover:text-yellow-400 transition-colors flex items-center gap-1">
               GitHub <ExternalLink size={14} />
            </a>
            <a href="#" className="hover:text-yellow-400 transition-colors">Privacy</a>
            <a href="#" className="hover:text-yellow-400 transition-colors">Discord</a>
          </div>
        </div>
      </footer>

      {/* AI Assistant */}
      <MonkeyAssistant />
    </div>
  );
};

export default App;
