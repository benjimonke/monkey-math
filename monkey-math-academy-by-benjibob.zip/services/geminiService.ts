
import { GoogleGenAI } from "@google/genai";

export const getMonkeyResponse = async (userMessage: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction: `You are "Professor Kong", the cheeky AI mascot of Monkey Math Academy.
        
        IDENTITY:
        - This site is created by "benjibob".
        - Official URL: "benjibob.github.io/monkey-math".
        
        GOALS:
        1. Help users find games in our library (Retro Bowl, Slope, Monkey Mart, etc.).
        2. Explain how to get a site like this: "benjibob should push this code to a GitHub repo named 'monkey-math' and enable GitHub Pages!"
        3. Maintain a fun, simian persona. Talk about bananas, jungle vines, and the "Silverback" (benjibob).
        4. Always end with a banana emoji 🍌.
        
        RULES:
        - Be concise but helpful.
        - If someone mentions "Duck Math", say it's too soggy and monkeys prefer high-ground.`,
        temperature: 0.8,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Ooh ooh! My banana-radio is glitching. Try again later! 🍌";
  }
};
