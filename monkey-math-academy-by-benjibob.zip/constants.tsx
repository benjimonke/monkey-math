
import { Game, GameCategory } from './types';

export const GAMES: Game[] = [
  {
    id: 'retro-bowl',
    title: 'Retro Bowl',
    category: 'Sports',
    thumbnail: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://game316009.konggames.com/game.html',
    description: 'The ultimate American football management game.',
    isHot: true,
  },
  {
    id: 'slope',
    title: 'Slope',
    category: 'Action',
    thumbnail: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://kdata1.com/2020/05/slope/',
    description: 'Dodge obstacles and reach the highest score.',
    isHot: true,
  },
  {
    id: 'monkey-mart',
    title: 'Monkey Mart',
    category: 'Math (wink)',
    thumbnail: 'https://images.unsplash.com/photo-1534278931827-8a259344abe7?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://monkey-mart.github.io/',
    description: 'Run your own monkey market. Learn economics!',
  },
  {
    id: '1v1-lol',
    title: '1v1.lol',
    category: 'Action',
    thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://1v1.lol/',
    description: 'Competitive build and shoot game.',
    isHot: true,
  },
  {
    id: 'drift-hunters',
    title: 'Drift Hunters',
    category: 'Driving',
    thumbnail: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://webgl.games/drift-hunters/',
    description: 'Realistic drifting simulator.',
  },
  {
    id: 'tunnel-rush',
    title: 'Tunnel Rush',
    category: 'Action',
    thumbnail: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://tunnelrush.github.io/',
    description: 'Fast-paced tunnel navigation.',
  },
  {
    id: 'bitlife',
    title: 'BitLife',
    category: 'Puzzle',
    thumbnail: 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://bitlifeonline.io/',
    description: 'Simulate your entire life.',
  },
  {
    id: 'geometry-dash',
    title: 'Geometry Dash',
    category: 'Puzzle',
    thumbnail: 'https://images.unsplash.com/photo-1614028674026-a65e31bfd27c?auto=format&fit=crop&q=80&w=400&h=300',
    embedUrl: 'https://geometrydash.io/',
    description: 'Jump and fly through danger.',
  }
];
