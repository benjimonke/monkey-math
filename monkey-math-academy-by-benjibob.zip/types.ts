
export interface Game {
  id: string;
  title: string;
  category: string;
  thumbnail: string;
  embedUrl: string;
  description: string;
  isHot?: boolean;
}

export enum GameCategory {
  ALL = 'All',
  ACTION = 'Action',
  SPORTS = 'Sports',
  DRIVING = 'Driving',
  PUZZLE = 'Puzzle',
  RETRO = 'Retro',
  MATH = 'Math (wink)'
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
